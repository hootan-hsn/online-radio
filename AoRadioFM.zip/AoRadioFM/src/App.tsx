import { useRef, useState } from 'react';

const STREAM = 'https://raadio.run.place';
const SKIP_API = 'https://run.place';
const FREQS = [88, 92, 96, 100, 104, 108];

export default function App() {
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const [status, setStatus] = useState('Ready');
  const audioRef = useRef<HTMLAudioElement>(null);
  const lastSync = useRef(0);
  const liveSrc = () => STREAM + '?' + Date.now();

  const resyncStream = () => {
    const el = audioRef.current;
    if (!el || Date.now() - lastSync.current < 2500) return;
    lastSync.current = Date.now();
    const wasPlaying = !el.paused;
    el.src = liveSrc();
    el.load();
    if (wasPlaying) {
      setTimeout(() => {
        el.play().catch(() => setStatus('Stream buffering, retrying...'));
      }, 800);
    }
  };

  const play = () => {
    const el = audioRef.current;
    if (!el) return;
    el.src = liveSrc();
    el.play()
      .then(() => { setPlaying(true); setStatus('Live stream connected.'); })
      .catch(() => setStatus('Connection buffering. Try again.'));
  };

  const skip = async () => {
    setStatus('Sending skip vote...');
    try {
      const res = await fetch(SKIP_API, { method: 'POST' });
      const data = await res.json();
      const msg = String(data.message || '');
      setStatus(msg);
      if (msg.includes('globally') || data.status === 'success') resyncStream();
    } catch {
      setStatus('Error reaching voting engine.');
    }
  };

  return (
    <div className="radio-container">
      <audio ref={audioRef} crossOrigin="anonymous" preload="none" onStalled={resyncStream} onError={resyncStream} />
      <div className="radio-body">
        <div className="wood-panel left" /><div className="wood-panel right" />
        <div className="radio-front">
          <div className="brand-plate">
            <h1 className="brand-name">AO-RADIO</h1>
            <span className="model-number">TRANSISTOR FM-2024</span>
          </div>
          <div className="speaker-grille"><div className="grille-mesh" /></div>
          <div className="tuning-section">
            <div className="tuning-glass">
              <div className="frequency-scale">
                <div className="scale-markers">{FREQS.map((f) => <span key={f}>{f}</span>)}</div>
                <div className="tuning-indicator" />
              </div>
              <div className="stream-info">
                <div className="station-name">LIVE STREAM</div>
                <div id="status" className="status">{status}</div>
              </div>
            </div>
          </div>
          <div className="controls-panel">
            <div className="control-group">
              <label>POWER / PLAY</label>
              <button
                id="play-btn"
                className={`vintage-switch ${playing ? 'on' : 'off'}`}
                onClick={() => playing ? (audioRef.current?.pause(), setPlaying(false)) : play()}
                aria-label={playing ? 'Pause' : 'Play'}
              >
                <div className="switch-toggle" />
              </button>
            </div>
            <div className="control-group">
              <label>VOTE TO SKIP</label>
              <button id="skip-btn" className="skip-button" onClick={skip} aria-label="Vote to skip">⏭</button>
            </div>
            <div className="control-group">
              <label>VOLUME</label>
              <div className="knob-container">
                <input
                  type="range" min="0" max="1" step="0.01" value={volume} className="volume-slider"
                  onChange={(e) => {
                    const v = +e.target.value;
                    setVolume(v);
                    if (audioRef.current) audioRef.current.volume = v;
                  }}
                />
                <div className="knob" style={{ transform: `rotate(${volume * 270 - 135}deg)` }}>
                  <div className="knob-indicator" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="footer-credits">&copy; 1954 AO ELECTRONICS CORP. | HI-FIDELITY SOUND</div>
    </div>
  );
}
