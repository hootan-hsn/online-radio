# AoRadio FM

Vintage-themed radio player. React, TypeScript, Vite.

```bash
npm install
npm run dev
```

Stream: `https://raadio.run.place`  
Skip votes: `POST https://run.place`
